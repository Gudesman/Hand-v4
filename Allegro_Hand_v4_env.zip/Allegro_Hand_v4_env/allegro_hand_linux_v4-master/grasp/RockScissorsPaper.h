#ifndef _ROCKSCISSORSPAPER_H
#define _ROCKSCISSORSPAPER_H

void MotionRock();
void MotionScissors();
void MotionPaper();

#endif

#define FILEVER 4,9,0,0
#define STRFILEVER "4.9.0.0"
#define STRPRODUCTVER "4.9"
#define COPYRIGHT "(C) 2024 PEAK-System Technik GmbH"
// linux API
#define VERSION_MAJOR		4
#define VERSION_MINOR		9
#define VERSION_PATCH		0
#define VERSION_BUILD		7

